﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            for(; ;)
            {
                Console.Write("Please enter the num of hexagon: ");
                int num = int.Parse(Console.ReadLine());
                if (num == 0) break;
                int i, j;
                for (i = 0; i < 2 * num - 1; i++)
                {
                    for (j = 0; j < Math.Abs(num-1-i)+1; j++)
                    {
                        Console.Write(" ");
                    }
                    if (i == 0 || i == 2 * num - 2)
                    {
                        for (j = 0; j < 2 * num - 1; j++)
                            Console.Write("*");
                        Console.Write("\n");
                    }
                    else
                    {
                        Console.Write("*");
                        for (j = 0; j < 2*num-1+num-2*Math.Abs(num-1-i)+num-4; j++)
                            Console.Write(" ");
                        Console.Write("*");
                        Console.Write("\n");
                    }
                }
            } 
            Console.Read();
        }
    }
}
//2num-1 + k
  //  k= Math.Abs(num - 1 - i) 
