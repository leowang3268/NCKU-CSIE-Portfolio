﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //read in the sequence, number of elements muse be odd. Press enter to end the reading.
            var input = new string[100];
            var int_type = new int[100];
            int i = 0, j = 0, cnt = 0;
            Console.WriteLine("Please enter the number: (press enter to stop)");
            while (true)
            {
                while ((input[cnt] = Console.ReadLine()) != "")
                {                  
                    int_type[cnt] = int.Parse(input[cnt]);
                    cnt++;
                }
                if (cnt % 2 == 1)
                    break;
            }

            //sort the sequence in increasing order
            int tmp = 0;
            for(i=0; i<cnt; i++)
            {
                for(j=i; j<cnt; j++)
                {
                    if(int_type[j]<int_type[i])
                    {
                        tmp = int_type[j];
                        int_type[j] = int_type[i];
                        int_type[i] = tmp; 
                    }
                }
            }

            tmp = 0;
            int median = int_type[(cnt - 1) / 2];

            //sort the sequence following the rule
            for(i=0; i<cnt; i++)
            {
                //if (i == (cnt - 1) / 2) continue;
                for(j=i; j<cnt; j++)
                {
                    if (j == (cnt - 1) / 2) continue;
                    if (Math.Abs(int_type[i] - median) < 
                        Math.Abs(int_type[j] - median))
                    {
                        tmp = int_type[j];
                        int_type[j] = int_type[i];
                        int_type[i] = tmp;
                    }
                    else if (Math.Abs(int_type[i] - median) ==
                        Math.Abs(int_type[j] - median))
                    {
                        if(int_type[j]>int_type[i])
                        {
                            tmp = int_type[j];
                            int_type[j] = int_type[i];
                            int_type[i] = tmp;
                        }
                    }
                }
            }

            //print out the sorted sequence
            Console.WriteLine("The sorted sequence is: ");
            for(i=0; i<cnt; i++)
            {
                Console.WriteLine(int_type[i]);
            }


            Console.ReadKey();   
        }
    }
}
