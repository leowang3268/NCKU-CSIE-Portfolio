﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice3_1
{
    class Program
    {

        static void Main(string[] args)
        {         
            Console.WriteLine("Please enter row and column: ");
            Console.WriteLine("Row: ");
            int row = int.Parse(Console.ReadLine());
            Console.WriteLine("Column: ");
            int column = int.Parse(Console.ReadLine());
            bool[,] visited = new bool[100, 100];
            char[,] map = new char[row, column];

            int i = 0, j = 0, cnt=0;

            string str = "";
            Console.WriteLine("Enter the map ('*': Land, '#': Water): ");
            for (i = 0; i < row; i++)
            {
                str  = Console.ReadLine();
                for (j = 0; j < column; j++)
                {
                    map[i, j] = str[j]; 
                    visited[i, j] = false;
                }                
            }

            for (i = 0; i < row; i++)
                for (j = 0; j < column; j++)
                    if (map[i, j] == '#' && visited[i, j] == false)
                    {
                        DFS(i, j, row, column, map, visited);
                        cnt++;
                    }

            Console.WriteLine("There are {0} river(s).", cnt);
   
            Console.Read();
        }

        public static void DFS(int i, int j, int row, int column, char[,] map, bool[,] visited) //, int row, int column, ref bool[,] visited, ref char[,] map
        {
            if (i < 0 || i >= row || j < 0 || j >= column || visited[i, j] == true || map[i, j] == '*')
                return;
            visited[i, j] = true;
            DFS(i - 1, j - 1, row, column, map, visited);
            DFS(i - 1, j, row, column, map, visited);
            DFS(i - 1, j + 1, row, column, map, visited);
            DFS(i, j - 1, row, column, map, visited);
            DFS(i, j + 1, row, column, map, visited);
            DFS(i + 1, j - 1, row, column, map, visited);
            DFS(i + 1, j, row, column, map, visited);
            DFS(i + 1, j + 1, row, column, map, visited);
            return;
        }
    }
}
