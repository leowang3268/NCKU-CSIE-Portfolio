﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice3_2
{
    class Program
    {
        
        private static void Swap(ref int a, ref int b)
        {
            var tmp = a;
            a = b;
            b = tmp;
        }

        public static void Permutation(ref int[] circle, int k, int m)//k是要開始排序的位置，m是要排的個數-1
        {
            if (k == m && Prime(ref circle)) 
            {
                for(int i = 0; i < circle.Length; i++)
                {
                    Console.Write(circle[i]);
                    Console.Write(' ');
                }
                Console.WriteLine();
            }
            else if (k < m)
            {
                for (int i = k; i <= m; i++)
                {
                    Swap(ref circle[k], ref circle[i]);
                    Permutation(ref circle, k + 1, m);
                    Swap(ref circle[k], ref circle[i]);
                }
            }
        }

        
        private static bool Prime(ref int[] circle)
        {
            for (int i = 0; i < circle.Length; i++)
            {

                int a = i % circle.Length, 
                    b = (i + 1) % circle.Length;
                for (int j = 2; j <= Math.Sqrt(circle[a] + circle[b]); j++) //一個數n要檢查是不是質數只需檢查到sqrt(n)
                {
                    if ((circle[a] + circle[b]) % j == 0)
                        return false;
                }
            }
            return true;
        }
        static void Main(string[] args)
        {
            
            int n;
            n = NewMethod();

            int[] circle = new int[n];
            int i, j, tmp = 0;

            for (i = 0; i < n; i++)
                circle[i] = i+1;

            Permutation(ref circle, 1, circle.Length - 1);

            Console.ReadKey();
        }

        private static int NewMethod()
        {
            int n;
            do
            {
                Console.WriteLine("Please enter an even number: (2<=n<=16)");
                n = int.Parse(Console.ReadLine());
            } while (n < 2 || n > 16 || n % 2 == 1);
            return n;
        }
    }
}
