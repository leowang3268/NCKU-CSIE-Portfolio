﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practice4_1
{
    public partial class Form1 : Form
    {
        public const int Encode = 0; // 加密
        public const int Decode = 1; // 解密
        public const int Encode_Decode = 2; // 加密後解密
        public const int MainMenu = 3; // 回到首頁
        public int status; // 表示現在功能

        public string record_string; // 歷史紀錄字串
        public Form1()
        {
            InitializeComponent();
            Encode_button.Visible = true; // 加密按紐
            Decode_button.Visible = true; // 解密按紐
            Encode_Decode_button.Visible = true; // 加密後再解密按紐
            record_button.Visible = true; // 歷史紀錄按紐
            OK_button.Visible = false; // OK按紐
            title_label.Visible = false; // 標題 Label
            string_label.Visible = false; // 加解密字串 Label
            shift_label.Visible = false; // 位移 Label

            deshift_label.Visible = false; // 解密位移 Label

            string_textBox.Visible = false; // 加解密字串 textBox
            shift_textBox.Visible = false; // 位移 textBox

            result_textBox.Visible = false; // 加/解密結果 textBox
            deshift_textBox.Visible = false; // 解密位移 textBox
            /*在這裡加入還需要的Label、Textbox*/


            /**********************************/
        }

        private void Encode_button_Click(object sender, EventArgs e)
        {
            //按 加密按紐
            Encode_button.Visible = false;
            Decode_button.Visible = false;
            Encode_Decode_button.Visible = false;
            record_button.Visible = false;
            OK_button.Visible = true;
            title_label.Visible = true;
            string_label.Visible = true;
            shift_label.Visible = true;
            string_textBox.Visible = true;
            shift_textBox.Visible = true;
            status = Encode;
        }

        private void Decode_button_Click(object sender, EventArgs e)
        {
            //按 解密按紐
            Encode_button.Visible = false;
            Decode_button.Visible = false;
            Encode_Decode_button.Visible = false;
            record_button.Visible = false;
            OK_button.Visible = true;
            title_label.Visible = true;
            string_label.Visible = true;
            shift_label.Visible = true;
            string_textBox.Visible = true;
            shift_textBox.Visible = true;
            status = Decode;
        }

        private void Encode_Decode_button_Click(object sender, EventArgs e)
        {
            //按 解密後再加密按紐
            Encode_button.Visible = false;
            Decode_button.Visible = false;
            Encode_Decode_button.Visible = false;
            record_button.Visible = false;
            OK_button.Visible = true;
            title_label.Visible = true;
            string_label.Visible = true;
            shift_label.Visible = true;
            deshift_label.Visible = true;
            string_textBox.Visible = true;
            shift_textBox.Visible = true;
            deshift_textBox.Visible = true;
            status = Encode_Decode;
        }

        private void record_button_Click(object sender, EventArgs e)
        {
            //按 歷史紀錄按紐
            status = MainMenu;
            result_textBox.Text = "";
            result_textBox.Text += record_string;
            title_label.Visible = true;
            result_textBox.Visible = true;
            OK_button.Visible = true;
            Encode_button.Visible = false;
            Decode_button.Visible = false;
            Encode_Decode_button.Visible = false;
            record_button.Visible = false;
        }

        private void OK_button_Click(object sender, EventArgs e)
        {
            switch (status)
            {
                case Encode:
                    //顯示加密後字串
                    status = MainMenu; // 更改狀態為 回到主頁面
                    title_label.Text = "加密";
                    result_textBox.Text = "";
                    result_textBox.Text += "加密後為 ";
                    string encode_result1 = "";
                    encode_result1 += Ceasar_Encode_Cipher(string_textBox.Text, int.Parse(shift_textBox.Text)); // 取得加密後字串
                    result_textBox.Text += encode_result1;
                    result_textBox.Visible = true;
                    string_label.Visible = false;
                    shift_label.Visible = false;
                    string_textBox.Visible = false;
                    shift_textBox.Visible = false;
                    record_string += "***加密***\r\n"; // 加入歷史紀錄
                    record_string += "原字串為 ";
                    record_string += string_textBox.Text;
                    record_string += "\r\n";
                    record_string += "新字串為 ";
                    record_string += encode_result1;
                    record_string += "\r\n";
                    break;
                case Decode:
                    //顯示解密後字串
                    status = MainMenu;
                    title_label.Text = "解密";
                    result_textBox.Text = "";
                    result_textBox.Text += "解密後為 ";
                    string decode_result1 = "";
                    decode_result1 += Ceasar_Encode_Cipher(string_textBox.Text, (-1) * int.Parse(shift_textBox.Text)); // 取得解密後字串
                    result_textBox.Text += decode_result1;
                    result_textBox.Visible = true;
                    string_label.Visible = false;
                    shift_label.Visible = false;
                    string_textBox.Visible = false;
                    shift_textBox.Visible = false;
                    record_string += "***解密***\r\n"; // 加入歷史紀錄
                    record_string += "原字串為 ";
                    record_string += string_textBox.Text;
                    record_string += "\r\n";
                    record_string += "新字串為 ";
                    record_string += decode_result1;
                    record_string += "\r\n";
                    break;
                case Encode_Decode:
                    //顯示解密與再加密字串
                    status = MainMenu;
                    title_label.Text = "解密後加密";
                    result_textBox.Text = "";
                    result_textBox.Text += "解密後為 ";
                    string decode_result2 = ""; 
                    decode_result2 += Ceasar_Encode_Cipher(string_textBox.Text, (-1) * int.Parse(shift_textBox.Text));
                    result_textBox.Text += decode_result2; 
                    result_textBox.Text += "\r\n加密後為";
                    string encode_result2 = "";
                    encode_result2 += Ceasar_Encode_Cipher(decode_result2, int.Parse(shift_textBox.Text));
                    result_textBox.Text += encode_result2;
                    result_textBox.Visible = true;
                    string_label.Visible = false;
                    shift_label.Visible = false;
                    deshift_label.Visible = false;
                    string_textBox.Visible = false;
                    shift_textBox.Visible = false;
                    deshift_textBox.Visible = false; 
                    record_string += "***解密後加密***\r\n"; // 加入歷史紀錄
                    record_string += "原字串為 ";
                    record_string += string_textBox.Text;
                    record_string += "\r\n";
                    record_string += "解密後字串為 ";
                    record_string += decode_result2;
                    record_string += "\r\n";
                    record_string += "加密後字串為 ";
                    record_string += encode_result2;
                    record_string += "\r\n";
                    break;
                case MainMenu:
                    //回到主頁面
                    Encode_button.Visible = true; // 加密按紐
                    Decode_button.Visible = true; // 解密按紐
                    Encode_Decode_button.Visible = true; // 加密後再解密按紐
                    record_button.Visible = true; // 歷史紀錄按紐
                    OK_button.Visible = false; // OK按紐
                    title_label.Visible = false; // 標題 Label

                    result_textBox.Visible = false; //加/解密結果 textBox

                    break;
            }
        }
        public string Ceasar_Encode_Cipher(string input, int shift) // 凱薩密碼加密 輸入字串與位移
        {
            //int positive_shift = Math.Abs(shift); // shift 改為正數
            string output = ""; // 輸出字串
            /*這裡是凱薩密碼加密演算法*/
            foreach(char c in input)
            {
                char c2 = c;
                if (c2 == ' ')
                    output += c2;

                else if (c2 >= 65 && c2 <= 90) //uppercase 
                {
                    if (shift > 0)
                        output += Convert.ToChar((c2 + shift - 'A') % 26 + 'A');
                    else if (shift < 0)
                        output += Convert.ToChar('Z' - ('Z' - c2 - shift) % 26);
                }

                else if (c2 >= 97 && c2 <= 122) //lowercase
                {
                    if (shift > 0)
                        output += Convert.ToChar((c2 + shift - 'a') % 26 + 'a');
                    else if (shift < 0)
                        output += Convert.ToChar('z' - ('z' - c2 - shift) % 26);
                }

             

            }

            /******************************/
            return output;
        }
    }
}
