﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dark_Age
{
    class Buildibngs
    {
        protected int HP;
        public int get_HP()
        {
            return HP;
        }
        public void set_HP(int value)
        {
            HP = value;
        }
    }
}
