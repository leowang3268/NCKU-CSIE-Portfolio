﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dark_Age
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Buildibngs []TC = new Buildibngs[0];
            Buildibngs []Barracks = new Buildibngs[0];
            Buildibngs []ArcheryRange = new Buildibngs[0];
            Buildibngs []Stable = new Buildibngs[0];
            Units []Villager = new Units[0];
            Units []Militia = new Units[0];
            Units []Archer = new Units[0];
            Units []Scout = new Units[0];

            /* Create first TC in Round 0 */
            int Round = 0;
            Array.Resize(ref TC, TC.Length + 1);
            TC[TC.Length - 1] = new Buildibngs();
            TC[TC.Length-1].set_HP(1000);
            int TC_cnt = TC.Length, Barracks_cnt = 0, ArcheryRange_cnt = 0, Stable_cnt = 0;
            int Villager_cnt = 0, Militia_cnt = 0, Archer_cnt = 0, Scout_cnt = 0;
            int Foods = 500;
            int Woods = 500;
            int Golds = 500;
            bool Victory = false;
            bool Lose = false;
            Console.WriteLine("Round {0}", Round);
            Console.WriteLine("Current Resources: Foods: {0}, Woods: {1}, Golds: {2}", Foods, Woods, Golds);
            Console.WriteLine("Current Buildings: TC x{0}, Barracks x{1}, ArcheryRange x{2}, Stable x{3}", TC_cnt, Barracks_cnt, ArcheryRange_cnt, Stable_cnt);
            Console.WriteLine("Current Units: Villager x{0}, Militia x{1}, Archer x{2}, Scout x{3}", Villager_cnt, Militia_cnt, Archer_cnt, Scout_cnt);

            while (!Victory && !Lose)
            {
                bool next_round = false; // initialized each round

                for (int i = 0; i < Villager_cnt; i++)
                {
                    Woods += 10;
                    Golds += 10;
                    Foods += 10;
                }
                
                /* Read in instruction */
                string instruction = Console.ReadLine();

                if (instruction == "skip")
                {
                    Round++;
                    next_round = true;
                }

                else if (instruction == "units_status")
                {
                    for (int i = 0; i < Villager.Length; i++)
                        if (Villager[i].get_HP() > 0)
                            Console.WriteLine("Villager  Attack: 2  HP: {0}", Villager[i].get_HP()); 
                    for (int j = 0; j < Militia.Length; j++)
                        if (Militia[j].get_HP() > 0)
                            Console.WriteLine("Militia  Attack: 10  HP: {0}", Militia[j].get_HP());
                    for (int k = 0; k < Archer.Length; k++)
                        if (Archer[k].get_HP() > 0)
                            Console.WriteLine("Archer  Attack: 15  HP: {0}", Archer[k].get_HP());
                    for (int l = 0; l < Scout.Length; l++)
                        if (Scout[l].get_HP() > 0)
                            Console.WriteLine("Scout  Attack: 5  HP: {0}", Scout[l].get_HP());
                }

                else if (instruction == "TC_status")
                {
                    for (int i = 0; i < TC_cnt; i++)
                        if (TC[i].get_HP() > 0)
                            Console.WriteLine("TC  HP: {0}", TC[i].get_HP());
                }

                else if (instruction == "Feudal")
                {
                    if (Foods >= 500)
                        Victory = true;
                    else
                        Console.WriteLine("The resources are not enough");
                }

                else if (instruction == "how_do_you_turn_this_on")
                {
                    Woods = 50000;
                    Golds = 50000;
                    Foods = 50000;
                }

                else if (instruction == "TC")
                {
                    if (Woods >= 200 && Golds >= 100)
                    {
                        Array.Resize(ref TC, TC.Length + 1);
                        TC[TC.Length - 1] = new Buildibngs();
                        TC[TC.Length - 1].set_HP(1000);
                        TC_cnt++;
                        Woods -= 200;
                        Golds -= 100;
                        Round++;
                        next_round = true;
                    }
                    else
                        Console.WriteLine("The resources are not enough");
                }

                else if (instruction == "Barracks")
                {
                    if (Woods >= 100)
                    {
                        Array.Resize(ref Barracks, Barracks.Length + 1);
                        Barracks[Barracks.Length - 1] = new Buildibngs();
                        Barracks[Barracks.Length - 1].set_HP(500);
                        Barracks_cnt++;
                        Woods -= 100;
                        Round++;
                        next_round = true;
                    }
                    else
                        Console.WriteLine("The resources are not enough");
                }

                else if (instruction == "ArcheryRange")
                {
                    if (Woods >= 150 && Golds >= 50)
                    {
                        Array.Resize(ref ArcheryRange, ArcheryRange.Length + 1);
                        ArcheryRange[ArcheryRange.Length - 1] = new Buildibngs();
                        ArcheryRange[ArcheryRange.Length - 1].set_HP(300);
                        ArcheryRange_cnt++;
                        Woods -= 150;
                        Golds -= 50;
                        Round++;
                        next_round = true;
                    }
                    else
                        Console.WriteLine("The resources are not enough");
                }

                else if (instruction == "Stable")
                {
                    if (Woods >= 200)
                    {
                        Array.Resize(ref Stable, Stable.Length + 1);
                        Stable[Stable.Length - 1] = new Buildibngs();
                        Stable[Stable.Length - 1].set_HP(300);
                        Stable_cnt++;
                        Woods -= 200;
                        Round++;
                        next_round = true;
                    }
                    else
                        Console.WriteLine("The resources are not enough");
                }

                else if (instruction == "Villager")
                {
                    if (Foods >= 50)
                    {
                        Array.Resize(ref Villager, Villager.Length + 1);
                        Villager[Villager.Length - 1] = new Units();
                        Villager[Villager.Length - 1].set_HP(50);
                        Villager_cnt++;
                        Foods -= 50;
                        Round++;
                        next_round = true;
                    }
                    else
                        Console.WriteLine("The resources are not enough / There are no buildings for spawning");
                }

                else if (instruction == "Militia")
                {
                    if (Foods >= 100 && Golds >= 50 && Barracks_cnt > 0)
                    {
                        Array.Resize(ref Militia, Militia.Length + 1);
                        Militia[Militia.Length - 1] = new Units();
                        Militia[Militia.Length - 1].set_HP(100);
                        Militia_cnt++;
                        Foods -= 100;
                        Golds -= 50;
                        Round++;
                        next_round = true;
                    }
                    else
                        Console.WriteLine("The resources are not enough / There are no buildings for spawning");
                }

                else if (instruction == "Archer")
                {
                    if (Woods >= 75 && Golds >= 25 && ArcheryRange_cnt > 0)
                    {
                        Array.Resize(ref Archer, Archer.Length + 1);
                        Archer[Archer.Length - 1] = new Units();
                        Archer[Archer.Length - 1].set_HP(75);
                        Archer_cnt++;
                        Woods -= 75;
                        Golds -= 25;
                        Round++;
                        next_round = true;
                    }
                    else
                        Console.WriteLine("The resources are not enough / There are no buildings for spawning");
                }

                else if (instruction == "Scout")
                {
                    if (Foods >= 80 && Stable_cnt > 0)
                    {
                        Array.Resize(ref Scout, Scout.Length + 1);
                        Scout[Scout.Length - 1] = new Units();
                        Scout[Scout.Length - 1].set_HP(80);
                        Scout_cnt++;
                        Foods -= 80;
                        Round++;
                        next_round = true;
                    }
                    else
                        Console.WriteLine("The resources are not enough / There are no buildings for spawning");

                }

                else
                {
                    Console.WriteLine("Unknown Instruction");
                }

                /* Attack stage */
                if (next_round && Round >= 3)
                {
                    if (Villager_cnt > 0 || Militia_cnt > 0 || Archer_cnt > 0 || Scout_cnt > 0)
                    {
                        Random rnd1 = new Random();
                        int x;
                        do
                        {
                            x = rnd1.Next(0, 4);
                        } while ((x == 0 && Villager_cnt == 0) ||
                            (x == 1 && Militia_cnt == 0) ||
                            (x == 2 && Archer_cnt == 0) ||
                            (x == 3 && Scout_cnt == 0));
                        Random rnd2 = new Random();
                        int y;
                        switch (x)
                        {
                            case 0:
                                do
                                {
                                    y = rnd2.Next(0, Villager.Length);
                                } while (Villager[y].get_HP() <= 0);

                                Villager[y].set_HP(Villager[y].get_HP() - 50);
                                if (Villager[y].get_HP() <= 0)
                                    Villager_cnt--;
                                break;
                            case 1:
                                do
                                {
                                    y = rnd2.Next(0, Militia.Length);
                                } while (Militia[y].get_HP() <= 0);

                                Militia[y].set_HP(Militia[y].get_HP() - 50);
                                if (Militia[y].get_HP() <= 0)
                                    Militia_cnt--;
                                break;
                            case 2:
                                do
                                {
                                    y = rnd2.Next(0, Archer.Length);
                                } while (Archer[y].get_HP() <= 0);

                                Archer[y].set_HP(Archer[y].get_HP() - 50);
                                if (Militia[y].get_HP() <= 0)
                                    Militia_cnt--;
                                break;
                            case 3:
                                do
                                {
                                    y = rnd2.Next(0, Scout.Length);
                                } while (Scout[y].get_HP() <= 0);

                                Scout[y].set_HP(Scout[y].get_HP() - 50);
                                if (Scout[y].get_HP() <= 0)
                                    Scout_cnt--;
                                break;
                        }

                    }
                    else
                    {
                        Random rnd3 = new Random();
                        int z = rnd3.Next(0, TC.Length);
                        TC[z].set_HP(TC[z].get_HP() - 500);
                        if (TC[z].get_HP() <= 0)
                            TC_cnt--;
                        if (TC_cnt == 0) // hereeeeeeeeeeeeeeeeeeeeeeeeeeeeee
                            Lose = true;
                    }
                }

                Console.WriteLine("\r\nRound {0}", Round);
                Console.WriteLine("Current Resources: Foods: {0}, Woods: {1}, Golds: {2}", Foods, Woods, Golds);
                Console.WriteLine("Current Buildings: TC x{0}, Barracks x{1}, ArcheryRange x{2}, Stable x{3}", TC_cnt, Barracks_cnt, ArcheryRange_cnt, Stable_cnt);
                Console.WriteLine("Current Units: Villager x{0}, Militia x{1}, Archer x{2}, Scout x{3}", Villager_cnt, Militia_cnt, Archer_cnt, Scout_cnt);
            }

            /* Win or Lose */
            if (Victory)
                Console.WriteLine("Victory!");
            else
                Console.WriteLine("You Lose!");

            Console.ReadKey();
        }
    }
}
