﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<int> nums = new List<int>(Enumerable.Range(0, 10));
        int digits_cnt = 0;
        int wrong_times = 0;
        private int getNumber()
        {
            Random rand = new Random();
            int index = rand.Next(0, nums.Count);
            int num = nums[index];
            nums.RemoveAt(index);
            return num;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Random rnd = new Random();
            
            label1.Text = rnd.Next(0, 9999).ToString("D4");
            label2.Text = "";
            button2.Text = getNumber().ToString();
            button3.Text = getNumber().ToString();
            button4.Text = getNumber().ToString();
            button5.Text = getNumber().ToString();
            button6.Text = getNumber().ToString();
            button7.Text = getNumber().ToString();
            button8.Text = getNumber().ToString();
            button9.Text = getNumber().ToString();
            button10.Text = getNumber().ToString();
            button11.Text = getNumber().ToString();
        }
        private void RefreshBtn_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            label1.Text = rnd.Next(0, 9999).ToString("D4");
        }

        
        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text += button2.Text;
            digits_cnt++;
            isCorrect();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label2.Text += button3.Text;
            digits_cnt++;
            isCorrect();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label2.Text += button4.Text;
            digits_cnt++;
            isCorrect();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label2.Text += button5.Text;
            digits_cnt++;
            isCorrect();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label2.Text += button6.Text;
            digits_cnt++;
            isCorrect();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label2.Text += button7.Text;
            digits_cnt++;
            isCorrect();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            label2.Text += button8.Text;
            digits_cnt++;
            isCorrect();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            label2.Text += button9.Text;
            digits_cnt++;
            isCorrect();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label2.Text += button10.Text;
            digits_cnt++;
            isCorrect();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            label2.Text += button11.Text;
            digits_cnt++;
            isCorrect();
        }

        private void isCorrect()
        {
            if (digits_cnt == 4)
            {
                if (label1.Text == label2.Text)
                {
                    MessageBox.Show("Correct!", "Correct", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    this.Close();
                }
                else
                {
                    wrong_times++;
                    MessageBox.Show(string.Format("Wrong! {0} time(s)", wrong_times), "Wrong", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    digits_cnt = 0;
                    Random rnd = new Random();
                    label1.Text = rnd.Next(0, 9999).ToString("D4");
                    label2.Text = "";
                    if (wrong_times == 3)  this.Close();
                }
            }
        }
    }
}
