﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
        }

        /* Byte Conversion */
        string unit1, unit2;
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            unit1 = "Byte";
        }


        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            unit1 = "KibiByte";
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            unit1 = "MebiByte";
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            unit1 = "GibiByte";
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton8.Checked)
            unit2 = "Byte";
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton7.Checked)
            unit2 = "KibiByte";
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton6.Checked)
            unit2 = "MebiByte";
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked)
                unit2 = "GibiByte";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /* 除2^10 */
            if (unit1 == "Byte" && unit2 == "KibiByte" ||
                unit1 == "KibiByte" && unit2 == "MebiByte" ||
                unit1 == "MebiByte" && unit2 == "GibiByte" )
            {
                double input = double.Parse(textBox1.Text);
                input /= Math.Pow(2, 10);
                textBox2.Text = input.ToString();
            }

            /* 乘2^10 */
            else if (unit1 == "KibiByte" && unit2 == "Byte" ||
                unit1 == "MebiByte" && unit2 == "KibiByte" ||
                unit1 == "GibiByte" && unit2 == "MebiByte")              
            {
                double input = double.Parse(textBox1.Text);
                input *= Math.Pow(2, 10);
                textBox2.Text = input.ToString();
            }

            /* 除2^20 */
            else if (unit1 == "Byte" && unit2 == "MebiByte" ||
                unit1 == "KibiByte" && unit2 == "GibiByte")  
            {
                double input = double.Parse(textBox1.Text);
                input /= Math.Pow(2, 20);
                textBox2.Text = input.ToString();
            }

            /* 乘2^20 */
            else if (unit1 == "MebiByte" && unit2 == "Byte" ||
                unit1 == "GibiByte" && unit2 == "KibiByte")
            {
                double input = double.Parse(textBox1.Text);
                input *= Math.Pow(2, 20);
                textBox2.Text = input.ToString();
            }

            /* 除2^30 */
            else if (unit1 == "Byte" && unit2 == "GibiByte")
            {
                double input = double.Parse(textBox1.Text);
                input /= Math.Pow(2, 30);
                textBox2.Text = input.ToString();
            }

            /* 乘2^30 */
            else if (unit1 == "GibiByte" && unit2 == "Byte")
            {
                double input = double.Parse(textBox1.Text);
                input *= Math.Pow(2, 30);
                textBox2.Text = input.ToString();
            }

            /* 一樣 */
            else
            {
                textBox2.Text = textBox1.Text;
            }
        }

        /* Base Conversion */
        string base1;
        bool isBinary = false, isOctal = false, isDecimal = false, isHex = false;
        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton9.Checked)
                base1 = "Binary";
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton10.Checked)
                base1 = "Octal";
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton11.Checked)
                base1 = "Decimal";
        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton12.Checked)
                base1 = "Hexadecimal";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            isBinary = true; 
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            isOctal = true;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            isDecimal = true;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            isHex = true;
        }

        
        private void button2_Click(object sender, EventArgs e)
        {
            bool wrong = false;
            if (base1 == "Decimal")
            {
                int i;
                for (i = 0; i < textBox3.Text.Length; i++)
                {
                    if (i < 0 || i > 9)
                    {
                        wrong = true;
                    }
                }
                if (!wrong)
                {
                    int n = int.Parse(textBox3.Text);

                    if (isBinary)
                    {
                        label3.Text = "Binary: " + Convert.ToString(n, 2);
                    }
                    if (isOctal)
                    {
                        label4.Text = "Octal: " + Convert.ToString(n, 8);
                    }
                    if (isDecimal)
                    {
                        label5.Text = "Decimal: " + textBox3.Text;
                    }
                    if (isHex)
                    {
                        label6.Text = "Headecimal: " + Convert.ToString(n, 16);
                    }
                }               
            }

            else if (base1 == "Binary")
            {
                int i;
                for (i = 0; i < textBox3.Text.Length; i++)
                {
                    if (textBox3.Text[i]-'0' < 0 || textBox3.Text[i]-'0' > 1)
                    {
                        wrong = true;
                    }
                }
                if (!wrong)
                {
                    int n = Convert.ToInt32(textBox3.Text, 2);

                    if (isBinary)
                    {
                        label3.Text = "Binary: " + textBox3.Text;
                    }
                    if (isOctal)
                    {
                        label4.Text = "Octal: " + Convert.ToString(n, 8);
                    }
                    if (isDecimal)
                    {
                        label5.Text = "Decimal: " + Convert.ToString(n, 10);
                    }
                    if (isHex)
                    {
                        label6.Text = "Headecimal: " + Convert.ToString(n, 16);
                    }
                }   
            }

            else if (base1 == "Octal")
            {
                int i;
                for (i = 0; i < textBox3.Text.Length; i++)
                {
                    if (textBox3.Text[i] - '0' < 0 || textBox3.Text[i] - '0' > 7)
                    {
                        wrong = true;
                    }
                }
                if (!wrong)
                {
                    int n = Convert.ToInt32(textBox3.Text, 8);

                    if (isBinary)
                    {
                        label3.Text = "Binary: " + Convert.ToString(n, 2);
                    }
                    if (isOctal)
                    {
                        label4.Text = "Octal: " + textBox3.Text;
                    }
                    if (isDecimal)
                    {
                        label5.Text = "Decimal: " + Convert.ToString(n, 10);
                    }
                    if (isHex)
                    {
                        label6.Text = "Headecimal: " + Convert.ToString(n, 16);
                    }
                }           
            }

            else if (base1 == "Hexadecimal")
            {
                int i;
                for (i = 0; i < textBox3.Text.Length; i++)
                {
                    if (!( (textBox3.Text[i] - '0' >= 0 && textBox3.Text[i] - '0' <= 9) ||
                        (textBox3.Text[i] >= 65 && textBox3.Text[i] <= 70) ||
                        (textBox3.Text[i] >= 97 && textBox3.Text[i] <= 102) ))
                    {
                        wrong = true;
                    }
                }
                if (!wrong)
                {
                    int n = Convert.ToInt32(textBox3.Text, 16);

                    if (isBinary)
                    {
                        label3.Text = "Binary: " + Convert.ToString(n, 2);
                    }
                    if (isOctal)
                    {
                        label4.Text = "Octal: " + Convert.ToString(n, 8);
                    }
                    if (isDecimal)
                    {
                        label5.Text = "Decimal: " + Convert.ToString(n, 10);
                    }
                    if (isHex)
                    {
                        label6.Text = "Headecimal: " + textBox3.Text.ToUpper();
                    }
                }                  
            }

            if (wrong)
                MessageBox.Show("Input is illegal!", "Wrong", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

        }


    }
}
