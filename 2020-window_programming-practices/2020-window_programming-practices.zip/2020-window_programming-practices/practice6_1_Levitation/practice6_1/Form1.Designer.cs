﻿namespace practice6_1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.num_comboBox = new System.Windows.Forms.ComboBox();
            this.num_label = new System.Windows.Forms.Label();
            this.life_label = new System.Windows.Forms.Label();
            this.lifeNum_label = new System.Windows.Forms.Label();
            this.start_button = new System.Windows.Forms.Button();
            this.life_timer = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // num_comboBox
            // 
            this.num_comboBox.FormattingEnabled = true;
            this.num_comboBox.Location = new System.Drawing.Point(642, 70);
            this.num_comboBox.Name = "num_comboBox";
            this.num_comboBox.Size = new System.Drawing.Size(121, 23);
            this.num_comboBox.TabIndex = 0;
            // 
            // num_label
            // 
            this.num_label.AutoSize = true;
            this.num_label.Location = new System.Drawing.Point(571, 73);
            this.num_label.Name = "num_label";
            this.num_label.Size = new System.Drawing.Size(57, 15);
            this.num_label.TabIndex = 1;
            this.num_label.Text = "Number:";
            // 
            // life_label
            // 
            this.life_label.AutoSize = true;
            this.life_label.Location = new System.Drawing.Point(571, 137);
            this.life_label.Name = "life_label";
            this.life_label.Size = new System.Drawing.Size(89, 15);
            this.life_label.TabIndex = 2;
            this.life_label.Text = "Life Duration:";
            // 
            // lifeNum_label
            // 
            this.lifeNum_label.AutoSize = true;
            this.lifeNum_label.Location = new System.Drawing.Point(668, 137);
            this.lifeNum_label.Name = "lifeNum_label";
            this.lifeNum_label.Size = new System.Drawing.Size(0, 15);
            this.lifeNum_label.TabIndex = 3;
            // 
            // start_button
            // 
            this.start_button.Location = new System.Drawing.Point(627, 197);
            this.start_button.Name = "start_button";
            this.start_button.Size = new System.Drawing.Size(75, 23);
            this.start_button.TabIndex = 4;
            this.start_button.Text = "Start";
            this.start_button.UseVisualStyleBackColor = true;
            this.start_button.Click += new System.EventHandler(this.start_button_Click);
            // 
            // life_timer
            // 
            this.life_timer.Enabled = true;
            this.life_timer.Tick += new System.EventHandler(this.life_timer_Tick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 41);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 79);
            this.button1.TabIndex = 6;
            this.button1.Text = "Q";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(137, 41);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(79, 79);
            this.button2.TabIndex = 7;
            this.button2.Text = "W";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(250, 41);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(79, 79);
            this.button3.TabIndex = 8;
            this.button3.Text = "E";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(360, 41);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(79, 79);
            this.button4.TabIndex = 9;
            this.button4.Text = "R";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(474, 41);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(80, 80);
            this.button5.TabIndex = 10;
            this.button5.Text = "T";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.Color.Black;
            this.button0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button0.Location = new System.Drawing.Point(23, 390);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(550, 40);
            this.button0.TabIndex = 11;
            this.button0.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.start_button);
            this.Controls.Add(this.lifeNum_label);
            this.Controls.Add(this.life_label);
            this.Controls.Add(this.num_label);
            this.Controls.Add(this.num_comboBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox num_comboBox;
        private System.Windows.Forms.Label num_label;
        private System.Windows.Forms.Label life_label;
        private System.Windows.Forms.Label lifeNum_label;
        private System.Windows.Forms.Button start_button;
        private System.Windows.Forms.Timer life_timer;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button0;
    }
}

