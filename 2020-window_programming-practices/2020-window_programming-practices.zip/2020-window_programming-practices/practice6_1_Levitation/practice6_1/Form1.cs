﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practice6_1
{
    public partial class Form1 : Form
    {
        int sec = 0;
        int one_tenth_sec = 0;
        

        public Form1()
        {
            InitializeComponent();        
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
            life_timer.Enabled = false;
            lifeNum_label.Text = "";
            num_comboBox.Items.Add("2");
            num_comboBox.Items.Add("3");
            num_comboBox.Items.Add("4");
            num_comboBox.Items.Add("5");
            button0.Visible = false;
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            button0.Enabled = false;
            start_button.Enabled = true;
            num_comboBox.Enabled = true;
        }

        private void start_button_Click(object sender, EventArgs e)
        {
            start_button.Enabled = false;
            num_comboBox.Enabled = false;
            life_timer.Enabled = true;
            button0.Visible = true;

            int num = int.Parse(num_comboBox.Text);
            if (num == 2)
            {
                button2.Visible = true;
                button4.Visible = true;
            }
            else if (num == 3)
            {
                button1.Visible = true;
                button3.Visible = true;
                button5.Visible = true;
            }
            else if (num == 4)
            {
                button1.Visible = true;
                button2.Visible = true;
                button4.Visible = true;
                button5.Visible = true;
            }
            else if (num == 5)
            {
                button1.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                button5.Visible = true;
            }
        }

        /*
            
            if (e.KeyCode == Keys.W)
            {
                button2.Location = new Point(button1.Location.X, button1.Location.Y - 3);
            }
            if (e.KeyCode == Keys.E)
            {
                button3.Location = new Point(button1.Location.X, button1.Location.Y - 3);
            }
            if (e.KeyCode == Keys.R)
            {
                button4.Location = new Point(button1.Location.X, button1.Location.Y - 3);
            }
            if (e.KeyCode == Keys.T)
            {
                button5.Location = new Point(button1.Location.X, button1.Location.Y - 3);
            }
            
        */

        private void life_timer_Tick(object sender, EventArgs e)
        {
            //紀錄經過秒數
            one_tenth_sec++;
            if (one_tenth_sec == 10)
            {
                sec++;
                one_tenth_sec = 0;
                lifeNum_label.Text = sec.ToString();
            }

            button1.Location = new Point(button1.Location.X, button1.Location.Y + 3);
            button2.Location = new Point(button2.Location.X, button2.Location.Y + 3); ;
            button3.Location = new Point(button3.Location.X, button3.Location.Y + 3);
            button4.Location = new Point(button4.Location.X, button4.Location.Y + 3);
            button5.Location = new Point(button5.Location.X, button5.Location.Y + 3);
            if (button1.Location.Y >= 250 || button2.Location.Y >= 250 ||
                button3.Location.Y >= 250 || button4.Location.Y >= 250 ||
                button5.Location.Y >= 250)
            {
                life_timer.Stop();
                MessageBox.Show("Life Duration: " + sec);
                Form1 form = new Form1();
                this.Hide();
                form.Show();
                
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch(e.KeyCode)
            {
                case Keys.Q:
                    button1.Location = new Point(button1.Location.X, button1.Location.Y - 10);
                    break;
                case Keys.W:
                    button2.Location = new Point(button2.Location.X, button2.Location.Y - 10);
                    break;
                case Keys.E:
                    button3.Location = new Point(button3.Location.X, button3.Location.Y - 10);
                    break;
                case Keys.R:
                    button4.Location = new Point(button4.Location.X, button4.Location.Y - 10);
                    break;
                case Keys.T:
                    button5.Location = new Point(button5.Location.X, button5.Location.Y - 10);
                    break;
            }
                
        }
    }    
}
