﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp10
{
    class Creature
    {
        private int hp, mp;
        public int atk;
        public int get_hp()
        {
            return hp;
        }

        public void set_hp(int health)
        {
            hp = health;
        }

        public int get_mp()
        {
            return mp;
        }

        public void set_mp(int magic)
        {
            mp = magic;
        }

        public void Injured(int value)
        {
            set_hp(hp - value);
        }
        public void Attack(Creature c)
        {
            c.Injured(atk);
        }
    }
}
