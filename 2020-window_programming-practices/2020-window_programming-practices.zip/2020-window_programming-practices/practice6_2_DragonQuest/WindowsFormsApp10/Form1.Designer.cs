﻿namespace WindowsFormsApp10
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.warrior_button = new System.Windows.Forms.Button();
            this.tank_button = new System.Windows.Forms.Button();
            this.ranger_button = new System.Windows.Forms.Button();
            this.level_label = new System.Windows.Forms.Label();
            this.game_name_label = new System.Windows.Forms.Label();
            this.status_textBox = new System.Windows.Forms.TextBox();
            this.player_label = new System.Windows.Forms.Label();
            this.mp_label_1 = new System.Windows.Forms.Label();
            this.atk_label_1 = new System.Windows.Forms.Label();
            this.attack_button = new System.Windows.Forms.Button();
            this.skill_button = new System.Windows.Forms.Button();
            this.continue_button = new System.Windows.Forms.Button();
            this.atk_label_2 = new System.Windows.Forms.Label();
            this.mp_label_2 = new System.Windows.Forms.Label();
            this.hp_label_2 = new System.Windows.Forms.Label();
            this.moster_label = new System.Windows.Forms.Label();
            this.role_label = new System.Windows.Forms.Label();
            this.level_cnt_label = new System.Windows.Forms.Label();
            this.hp_label_1 = new System.Windows.Forms.Label();
            this.pHP_label = new System.Windows.Forms.Label();
            this.pMP_label = new System.Windows.Forms.Label();
            this.pATK_label = new System.Windows.Forms.Label();
            this.mATK_label = new System.Windows.Forms.Label();
            this.mMP_label = new System.Windows.Forms.Label();
            this.mHP_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // warrior_button
            // 
            this.warrior_button.Location = new System.Drawing.Point(636, 98);
            this.warrior_button.Name = "warrior_button";
            this.warrior_button.Size = new System.Drawing.Size(80, 38);
            this.warrior_button.TabIndex = 1;
            this.warrior_button.Text = "Warrior";
            this.warrior_button.UseVisualStyleBackColor = true;
            this.warrior_button.Click += new System.EventHandler(this.warrior_button_Click);
            // 
            // tank_button
            // 
            this.tank_button.Location = new System.Drawing.Point(103, 98);
            this.tank_button.Name = "tank_button";
            this.tank_button.Size = new System.Drawing.Size(82, 38);
            this.tank_button.TabIndex = 2;
            this.tank_button.Text = "Tank";
            this.tank_button.UseVisualStyleBackColor = true;
            this.tank_button.Click += new System.EventHandler(this.tank_button_Click);
            // 
            // ranger_button
            // 
            this.ranger_button.Location = new System.Drawing.Point(357, 98);
            this.ranger_button.Name = "ranger_button";
            this.ranger_button.Size = new System.Drawing.Size(83, 38);
            this.ranger_button.TabIndex = 3;
            this.ranger_button.Text = "Ranger";
            this.ranger_button.UseVisualStyleBackColor = true;
            this.ranger_button.Click += new System.EventHandler(this.ranger_button_Click);
            // 
            // level_label
            // 
            this.level_label.AutoSize = true;
            this.level_label.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.level_label.Location = new System.Drawing.Point(700, 20);
            this.level_label.Name = "level_label";
            this.level_label.Size = new System.Drawing.Size(59, 26);
            this.level_label.TabIndex = 4;
            this.level_label.Text = "Level: ";
            // 
            // game_name_label
            // 
            this.game_name_label.AutoSize = true;
            this.game_name_label.Font = new System.Drawing.Font("ROG Fonts", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.game_name_label.Location = new System.Drawing.Point(12, 352);
            this.game_name_label.Name = "game_name_label";
            this.game_name_label.Size = new System.Drawing.Size(771, 48);
            this.game_name_label.TabIndex = 5;
            this.game_name_label.Text = "             Dragon Quest             ";
            this.game_name_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // status_textBox
            // 
            this.status_textBox.Location = new System.Drawing.Point(247, 16);
            this.status_textBox.Multiline = true;
            this.status_textBox.Name = "status_textBox";
            this.status_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.status_textBox.Size = new System.Drawing.Size(326, 410);
            this.status_textBox.TabIndex = 6;
            // 
            // player_label
            // 
            this.player_label.AutoSize = true;
            this.player_label.Font = new System.Drawing.Font("MS Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player_label.Location = new System.Drawing.Point(32, 81);
            this.player_label.Name = "player_label";
            this.player_label.Size = new System.Drawing.Size(88, 24);
            this.player_label.TabIndex = 7;
            this.player_label.Text = "Player";
            // 
            // mp_label_1
            // 
            this.mp_label_1.AutoSize = true;
            this.mp_label_1.Location = new System.Drawing.Point(32, 171);
            this.mp_label_1.Name = "mp_label_1";
            this.mp_label_1.Size = new System.Drawing.Size(36, 15);
            this.mp_label_1.TabIndex = 9;
            this.mp_label_1.Text = "MP: ";
            // 
            // atk_label_1
            // 
            this.atk_label_1.AutoSize = true;
            this.atk_label_1.Location = new System.Drawing.Point(32, 207);
            this.atk_label_1.Name = "atk_label_1";
            this.atk_label_1.Size = new System.Drawing.Size(44, 15);
            this.atk_label_1.TabIndex = 10;
            this.atk_label_1.Text = "ATK: ";
            // 
            // attack_button
            // 
            this.attack_button.Location = new System.Drawing.Point(59, 266);
            this.attack_button.Name = "attack_button";
            this.attack_button.Size = new System.Drawing.Size(103, 41);
            this.attack_button.TabIndex = 15;
            this.attack_button.Text = "Attack";
            this.attack_button.UseVisualStyleBackColor = true;
            this.attack_button.Click += new System.EventHandler(this.attack_button_Click);
            // 
            // skill_button
            // 
            this.skill_button.Location = new System.Drawing.Point(59, 328);
            this.skill_button.Name = "skill_button";
            this.skill_button.Size = new System.Drawing.Size(103, 41);
            this.skill_button.TabIndex = 16;
            this.skill_button.Text = "Skill";
            this.skill_button.UseVisualStyleBackColor = true;
            this.skill_button.Click += new System.EventHandler(this.skill_button_Click);
            // 
            // continue_button
            // 
            this.continue_button.Location = new System.Drawing.Point(675, 385);
            this.continue_button.Name = "continue_button";
            this.continue_button.Size = new System.Drawing.Size(103, 41);
            this.continue_button.TabIndex = 20;
            this.continue_button.Text = "Continue";
            this.continue_button.UseVisualStyleBackColor = true;
            this.continue_button.Click += new System.EventHandler(this.continue_button_Click);
            // 
            // atk_label_2
            // 
            this.atk_label_2.AutoSize = true;
            this.atk_label_2.Location = new System.Drawing.Point(672, 207);
            this.atk_label_2.Name = "atk_label_2";
            this.atk_label_2.Size = new System.Drawing.Size(44, 15);
            this.atk_label_2.TabIndex = 23;
            this.atk_label_2.Text = "ATK: ";
            // 
            // mp_label_2
            // 
            this.mp_label_2.AutoSize = true;
            this.mp_label_2.Location = new System.Drawing.Point(672, 171);
            this.mp_label_2.Name = "mp_label_2";
            this.mp_label_2.Size = new System.Drawing.Size(36, 15);
            this.mp_label_2.TabIndex = 22;
            this.mp_label_2.Text = "MP: ";
            // 
            // hp_label_2
            // 
            this.hp_label_2.AutoSize = true;
            this.hp_label_2.Location = new System.Drawing.Point(672, 133);
            this.hp_label_2.Name = "hp_label_2";
            this.hp_label_2.Size = new System.Drawing.Size(33, 15);
            this.hp_label_2.TabIndex = 21;
            this.hp_label_2.Text = "HP: ";
            // 
            // moster_label
            // 
            this.moster_label.AutoSize = true;
            this.moster_label.Font = new System.Drawing.Font("MS Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moster_label.Location = new System.Drawing.Point(671, 81);
            this.moster_label.Name = "moster_label";
            this.moster_label.Size = new System.Drawing.Size(101, 24);
            this.moster_label.TabIndex = 24;
            this.moster_label.Text = "Monster";
            // 
            // role_label
            // 
            this.role_label.AutoSize = true;
            this.role_label.Font = new System.Drawing.Font("Segoe Print", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.role_label.Location = new System.Drawing.Point(28, 34);
            this.role_label.Name = "role_label";
            this.role_label.Size = new System.Drawing.Size(238, 43);
            this.role_label.TabIndex = 25;
            this.role_label.Text = "Choose Your  Role";
            // 
            // level_cnt_label
            // 
            this.level_cnt_label.AutoSize = true;
            this.level_cnt_label.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.level_cnt_label.Location = new System.Drawing.Point(749, 20);
            this.level_cnt_label.Name = "level_cnt_label";
            this.level_cnt_label.Size = new System.Drawing.Size(23, 26);
            this.level_cnt_label.TabIndex = 26;
            this.level_cnt_label.Text = "1";
            // 
            // hp_label_1
            // 
            this.hp_label_1.AutoSize = true;
            this.hp_label_1.Location = new System.Drawing.Point(32, 133);
            this.hp_label_1.Name = "hp_label_1";
            this.hp_label_1.Size = new System.Drawing.Size(33, 15);
            this.hp_label_1.TabIndex = 8;
            this.hp_label_1.Text = "HP: ";
            // 
            // pHP_label
            // 
            this.pHP_label.AutoSize = true;
            this.pHP_label.Location = new System.Drawing.Point(82, 133);
            this.pHP_label.Name = "pHP_label";
            this.pHP_label.Size = new System.Drawing.Size(0, 15);
            this.pHP_label.TabIndex = 27;
            // 
            // pMP_label
            // 
            this.pMP_label.AutoSize = true;
            this.pMP_label.Location = new System.Drawing.Point(82, 171);
            this.pMP_label.Name = "pMP_label";
            this.pMP_label.Size = new System.Drawing.Size(0, 15);
            this.pMP_label.TabIndex = 28;
            // 
            // pATK_label
            // 
            this.pATK_label.AutoSize = true;
            this.pATK_label.Location = new System.Drawing.Point(82, 207);
            this.pATK_label.Name = "pATK_label";
            this.pATK_label.Size = new System.Drawing.Size(0, 15);
            this.pATK_label.TabIndex = 29;
            // 
            // mATK_label
            // 
            this.mATK_label.AutoSize = true;
            this.mATK_label.Location = new System.Drawing.Point(727, 207);
            this.mATK_label.Name = "mATK_label";
            this.mATK_label.Size = new System.Drawing.Size(0, 15);
            this.mATK_label.TabIndex = 32;
            // 
            // mMP_label
            // 
            this.mMP_label.AutoSize = true;
            this.mMP_label.Location = new System.Drawing.Point(727, 171);
            this.mMP_label.Name = "mMP_label";
            this.mMP_label.Size = new System.Drawing.Size(0, 15);
            this.mMP_label.TabIndex = 31;
            // 
            // mHP_label
            // 
            this.mHP_label.AutoSize = true;
            this.mHP_label.Location = new System.Drawing.Point(727, 133);
            this.mHP_label.Name = "mHP_label";
            this.mHP_label.Size = new System.Drawing.Size(0, 15);
            this.mHP_label.TabIndex = 30;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp10.Properties.Resources.dragon_quest_switch_art;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.mATK_label);
            this.Controls.Add(this.mMP_label);
            this.Controls.Add(this.mHP_label);
            this.Controls.Add(this.pATK_label);
            this.Controls.Add(this.pMP_label);
            this.Controls.Add(this.pHP_label);
            this.Controls.Add(this.level_cnt_label);
            this.Controls.Add(this.warrior_button);
            this.Controls.Add(this.role_label);
            this.Controls.Add(this.moster_label);
            this.Controls.Add(this.atk_label_2);
            this.Controls.Add(this.mp_label_2);
            this.Controls.Add(this.hp_label_2);
            this.Controls.Add(this.continue_button);
            this.Controls.Add(this.skill_button);
            this.Controls.Add(this.atk_label_1);
            this.Controls.Add(this.mp_label_1);
            this.Controls.Add(this.hp_label_1);
            this.Controls.Add(this.player_label);
            this.Controls.Add(this.game_name_label);
            this.Controls.Add(this.level_label);
            this.Controls.Add(this.ranger_button);
            this.Controls.Add(this.tank_button);
            this.Controls.Add(this.status_textBox);
            this.Controls.Add(this.attack_button);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button warrior_button;
        private System.Windows.Forms.Button tank_button;
        private System.Windows.Forms.Button ranger_button;
        private System.Windows.Forms.Label level_label;
        private System.Windows.Forms.Label game_name_label;
        private System.Windows.Forms.TextBox status_textBox;
        private System.Windows.Forms.Label player_label;
        private System.Windows.Forms.Label mp_label_1;
        private System.Windows.Forms.Label atk_label_1;
        private System.Windows.Forms.Button attack_button;
        private System.Windows.Forms.Button skill_button;
        private System.Windows.Forms.Button continue_button;
        private System.Windows.Forms.Label atk_label_2;
        private System.Windows.Forms.Label mp_label_2;
        private System.Windows.Forms.Label hp_label_2;
        private System.Windows.Forms.Label moster_label;
        private System.Windows.Forms.Label role_label;
        private System.Windows.Forms.Label level_cnt_label;
        private System.Windows.Forms.Label hp_label_1;
        private System.Windows.Forms.Label pHP_label;
        private System.Windows.Forms.Label pMP_label;
        private System.Windows.Forms.Label pATK_label;
        private System.Windows.Forms.Label mATK_label;
        private System.Windows.Forms.Label mMP_label;
        private System.Windows.Forms.Label mHP_label;
    }
}

