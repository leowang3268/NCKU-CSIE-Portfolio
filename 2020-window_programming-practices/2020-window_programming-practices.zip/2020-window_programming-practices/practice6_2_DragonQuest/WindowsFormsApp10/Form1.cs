﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();   
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            status_textBox.Text = "";
            level_label.Text = "Level: ";
            level_cnt_label.Text = "1";
            game_name_label.Visible = true;
            role_label.Visible = true;
            warrior_button.Visible = true;
            tank_button.Visible = true;
            ranger_button.Visible = true;
            player_label.Visible = false;
            hp_label_1.Visible = false;
            mp_label_1.Visible = false;
            atk_label_1.Visible = false;
            hp_label_2.Visible = false;
            mp_label_2.Visible = false;
            atk_label_2.Visible = false;
            pHP_label.Visible = false;
            pMP_label.Visible = false;
            pATK_label.Visible = false;
            moster_label.Visible = false;
            mHP_label.Visible = false;
            mMP_label.Visible = false;
            mATK_label.Visible = false;
            attack_button.Visible = false;
            skill_button.Visible = false;
            status_textBox.Visible = false;
            continue_button.Visible = false;
        }

        Monster mon = new Monster();
        Warrior war = new Warrior();
        Tank tan = new Tank();
        Ranger ran = new Ranger();
        string Role = "";
        bool isPlayer = true;
        bool buff = false;
        bool isWin = false;
        bool isLose = false;
        public void InitializeMonster()
        {
            mon.GenerateMonster();
            mATK_label.Text = mon.atk.ToString();
            mHP_label.Text = mon.get_hp().ToString();
            mMP_label.Text = mon.get_mp().ToString();
        }
        public void Start()
        {         
            isPlayer = true;
            buff = false;
            isWin = false;
            isLose = false;
            InitializeMonster();
            status_textBox.Text = "Monster is Appear.\r\n";
            player_label.Visible = true;
            hp_label_1.Visible = true;
            mp_label_1.Visible = true;
            atk_label_1.Visible = true;
            hp_label_2.Visible = true;
            mp_label_2.Visible = true;
            atk_label_2.Visible = true;
            pHP_label.Visible = true;
            pMP_label.Visible = true;
            pATK_label.Visible = true;
            moster_label.Visible = true;
            mHP_label.Visible = true;
            mMP_label.Visible = true;
            mATK_label.Visible = true;
            attack_button.Visible = true;
            attack_button.Enabled = true;
            skill_button.Visible = true;
            skill_button.Enabled = true;
            status_textBox.Visible = true;
            continue_button.Visible = true;
            continue_button.Enabled = false;
            game_name_label.Visible = false;
            role_label.Visible = false;
            warrior_button.Visible = false;
            tank_button.Visible = false;
            ranger_button.Visible = false;
        }
  
        private void warrior_button_Click(object sender, EventArgs e)
        {
            Start();
            Role = "Warrior";
            player_label.Text = Role;
            war.GenerateWarrior();
            pATK_label.Text = war.atk.ToString();
            pHP_label.Text = war.get_hp().ToString();
            pMP_label.Text = war.get_mp().ToString();
            
        }

        private void tank_button_Click(object sender, EventArgs e)
        {
            Start();
            Role = "Tank";
            player_label.Text = Role;
            tan.GenerateTank();
            pATK_label.Text = tan.atk.ToString();
            pHP_label.Text = tan.get_hp().ToString();
            pMP_label.Text = tan.get_mp().ToString();
        }

        private void ranger_button_Click(object sender, EventArgs e)
        {
            Start();
            Role = "Ranger";
            player_label.Text = Role;
            ran.GenerateRanger();
            pATK_label.Text = ran.atk.ToString();
            pHP_label.Text = ran.get_hp().ToString();
            pMP_label.Text = ran.get_mp().ToString();
        }

        public void Win_or_Lose()
        {
            
            if (mon.get_hp() <= 0)
            {
                continue_button.Enabled = true;
                isWin = true;
                attack_button.Enabled = false;
                skill_button.Enabled = false;
                status_textBox.Text += "You Won, Hero. You Gain 30HP and 10MP.\r\n" +
                    "Let's Continue Our Endless Adventure.\r\n";

                if (Role == "Warrior")
                {
                    //if (Role == "Warrior")
                    //{
                    war.set_hp(war.get_hp() + 30);
                    pHP_label.Text = war.get_hp().ToString();
                    war.set_mp(war.get_mp() + 10);
                    pMP_label.Text = war.get_mp().ToString();
                    //}
                    /*
                    else if (Role == "Tank")
                    {
                        tan.set_hp(tan.get_hp() + 30);
                        pHP_label.Text = tan.get_hp().ToString();
                        tan.set_mp(tan.get_mp() + 10);
                        pMP_label.Text = tan.get_mp().ToString();
                    }
                    else if (Role == "Ranger")
                    {
                        ran.set_hp(ran.get_hp() + 30);
                        pHP_label.Text = ran.get_hp().ToString();
                        ran.set_mp(ran.get_mp() + 10);
                        pMP_label.Text = ran.get_mp().ToString();
                    }
                    */

                }

                else if (Role == "Tank")
                {
                    tan.set_hp(tan.get_hp() + 30);
                    pHP_label.Text = tan.get_hp().ToString();
                    tan.set_mp(tan.get_mp() + 10);
                    pMP_label.Text = tan.get_mp().ToString();
                }

                else if (Role == "Ranger")
                {
                    ran.set_hp(ran.get_hp() + 30);
                    pHP_label.Text = ran.get_hp().ToString();
                    ran.set_mp(ran.get_mp() + 10);
                    pMP_label.Text = ran.get_mp().ToString();
                }
            }



            else if ((Role == "Warrior" && war.get_hp() <= 0) ||
                Role == "Tank" && tan.get_hp() <= 0 ||
                Role == "Ranger" && ran.get_hp() <= 0)  
            {
                isLose = true;
                continue_button.Enabled = true;
                attack_button.Enabled = false;
                skill_button.Enabled = false;             
                status_textBox.Text += "You are defeated.\r\n" +
                    "Let's Retern to the Village for Some Rest and Restart Other Times.\r\n";
            }
        }


        private void continue_button_Click(object sender, EventArgs e)
        {
            if (isWin)
            {
                Start();
                level_cnt_label.Text = (int.Parse(level_cnt_label.Text) + 1).ToString();
            }

            else
            {
                Form1_Load(sender, e);
            }
            

        }

        public void MonsterRound() //可能還要修改
        {
            attack_button.Enabled = false;
            skill_button.Enabled = false;
            Random rnd = new Random();
            int useSkill = rnd.Next(0, 5);
            if (useSkill == 0)
            {
                if (mon.get_mp() < 5)
                    status_textBox.Text += "Monster Doesn't Have Enough MP!\r\n";
                else
                {
                    mon.DarkBlessing();
                    mHP_label.Text = mon.get_hp().ToString();
                    mMP_label.Text = mon.get_mp().ToString();
                    mATK_label.Text = mon.atk.ToString();
                    status_textBox.Text += "Monster Uses DarkBlessing.\r\n" +
                        "Monster Gains 20 HP and 10 ATK\r\n";
                }
            }
            else
            {
                status_textBox.Text += "Monster Attacks.\r\n";

                if (Role == "Warrior")
                {
                    mon.Attack(war);
                    pHP_label.Text = war.get_hp().ToString();
                    if (war.get_hp() < 0)
                        pHP_label.Text = "0";
                    status_textBox.Text += $"Warrior is Injured by {mon.atk} Points Damage.\r\n";
                }
                else if (Role == "Tank")
                {
                    if (buff)
                    {
                        tan.set_hp(tan.get_hp() + mon.atk);
                        pHP_label.Text = tan.get_hp().ToString();
                        status_textBox.Text += "Tank Uses Magic Shield! Tank Absorbs the Damage.\r\n";
                        buff = false;
                    }
                    else
                    {
                        mon.Attack(tan);
                        pHP_label.Text = tan.get_hp().ToString();
                        if (tan.get_hp() < 0)
                            pHP_label.Text = "0";
                        status_textBox.Text += $"Tank is Injured by {mon.atk} Points Damage.\r\n";
                    }
                }

                else if (Role == "Ranger")
                {
                    mon.Attack(ran);
                    pHP_label.Text = ran.get_hp().ToString();
                    if (ran.get_hp() < 0)
                        pHP_label.Text = "0";
                    status_textBox.Text += $"Ranger is Injured by {mon.atk} Points Damage.\r\n";
                }     
            }
            Win_or_Lose();
            if (!isLose)
            {
                isPlayer = true;
                attack_button.Enabled = true;
                skill_button.Enabled = true;
            }   
        }

        private void attack_button_Click(object sender, EventArgs e)
        {
            status_textBox.Text += $"{Role} Attacks.\r\n";
            
            if (Role == "Warrior")
            {
                war.Attack(mon);
                mHP_label.Text = mon.get_hp().ToString();
                if (mon.get_hp() < 0)
                    mHP_label.Text = "0";
                status_textBox.Text += $"Monster is Injured by 20 Points Damage.\r\n";
            }
                
            else if (Role == "Tank")
            {
                tan.Attack(mon);
                mHP_label.Text = mon.get_hp().ToString();
                if (mon.get_hp() < 0)
                    mHP_label.Text = "0";
                status_textBox.Text += "Monster is Injured by 15 Points Damage.\r\n";
            }
            
            else if (Role == "Ranger")
            {
                ran.Attack(mon);
                mHP_label.Text = mon.get_hp().ToString();
                if (mon.get_hp() < 0)
                    mHP_label.Text = "0";
                status_textBox.Text += "Monster is Injured by 25 Points Damage.\r\n";
            }

            Win_or_Lose();
            if (!isWin)
            {
                isPlayer = false;
                MonsterRound();
            }          
        }

        public void BloodThirsty()
        {
            if (war.get_mp() < 5)
                status_textBox.Text += "Player Doesn't Have Enough MP!\r\n";
            else
            {
                war.set_mp(war.get_mp() - 5);
                pMP_label.Text = war.get_mp().ToString();
                war.Attack(mon);
                war.set_hp(war.get_hp() + war.atk);
                pHP_label.Text = war.get_hp().ToString();
                mHP_label.Text = mon.get_hp().ToString();
                if (mon.get_hp() < 0)
                    mHP_label.Text = "0";
                status_textBox.Text += "Warrior is Bloodthisty!\r\n" +
                    "Warrior Causes and Absorbs the Damage.\r\n";
                status_textBox.Text += "Monster is Injured by 20 Points Damage.\r\n";
            }
        }

        public void MagicShield()
        {
            if (tan.get_mp() < 5)
                status_textBox.Text += "Player Doesn't Have Enough MP!\r\n";
            else
            {
                tan.set_mp(tan.get_mp() - 5);
                pMP_label.Text = tan.get_mp().ToString();
                buff = true;
            }
        }

        public void StardustStream()
        {
            if (ran.get_mp() < 5)
                status_textBox.Text += "Player Doesn't Have Enough MP!\r\n";
            else
            {
                ran.set_mp(ran.get_mp() - 5);
                pMP_label.Text = ran.get_mp().ToString();
                ran.Attack(mon);
                ran.Attack(mon);
                mHP_label.Text = mon.get_hp().ToString();
                if (mon.get_hp() < 0)
                    mHP_label.Text = "0";
                status_textBox.Text += "Ranger Uses StardustStream!\r\n";
                status_textBox.Text += "Monster is Injured by 50 Points Damage.\r\n";
            }
        }
        private void skill_button_Click(object sender, EventArgs e)
        {
            if (Role == "Warrior")
                BloodThirsty();

            else if (Role == "Tank")
                MagicShield();

            else if (Role == "Ranger")
                StardustStream();

            Win_or_Lose();
            if (!isWin)
            {
                isPlayer = false;
                MonsterRound();
            }       
        }

        
    }
}
