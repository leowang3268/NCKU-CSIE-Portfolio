﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp10
{
    class Monster : Creature
    {
        public void GenerateMonster()
        {
            atk = 20;
            set_hp(70);
            set_mp(10);
        }

        public void DarkBlessing()
        {
            set_mp(get_mp() - 5);
            set_hp(get_hp() + 20);
            atk += 10;
        }
    }
}
