﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp10
{
    class Ranger : Creature
    {
        public void GenerateRanger()
        {
            atk = 25;
            set_hp(80);
            set_mp(20);
        }
    }
}
