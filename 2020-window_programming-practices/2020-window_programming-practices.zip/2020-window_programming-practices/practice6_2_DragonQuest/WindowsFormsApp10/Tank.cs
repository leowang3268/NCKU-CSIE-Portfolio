﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp10
{
    class Tank : Creature
    {
        public void GenerateTank()
        {
            atk = 15;
            set_hp(150);
            set_mp(15);
        }
    }
}
