﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp10
{
    class Warrior : Creature
    {
        public void GenerateWarrior()
        {
            atk = 20;
            set_hp(100);
            set_mp(15);
        }

        
    }
}
