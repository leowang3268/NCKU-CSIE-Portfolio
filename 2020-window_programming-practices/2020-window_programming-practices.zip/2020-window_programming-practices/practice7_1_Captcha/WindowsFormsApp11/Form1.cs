﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private int getNumber(int min, int max) //隨機出一個數字
        {
            Random rnd = new Random();
            int num = rnd.Next(min, max);
            return num;
        }
       
        private void setText(int ch_pos, string ch) //設定label的字串
        {
            if (ch_pos == 1)
                label1.Text = ch;
            else if (ch_pos == 2)
                label2.Text = ch;
            else if (ch_pos == 3)
                label3.Text = ch;
            else if (ch_pos == 4)
                label4.Text = ch;
            else if (ch_pos == 5)
                label5.Text = ch;
            else if (ch_pos == 6)
                label6.Text = ch;
            else if (ch_pos == 7)
                label7.Text = ch;
            else if (ch_pos == 8)
                label8.Text = ch;
        }

        int w_pos = 0, q_pos = 0, e_pos = 0, r_pos = 0;


        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
            label8.Text = "";

            w_pos = getNumber(1, 9);

            do
            {
                q_pos = getNumber(1, 9);
            } while (q_pos == w_pos || q_pos == w_pos + 4 || q_pos == w_pos - 4);
            do
            {
                e_pos = getNumber(1, 9);
            } while (e_pos == w_pos || e_pos == w_pos + 4 || e_pos == w_pos - 4 ||
                    e_pos == q_pos || e_pos == q_pos + 4 || e_pos == q_pos - 4);
            do
            {
                r_pos = getNumber(1, 9);
            } while (r_pos == w_pos || r_pos == w_pos + 4 || r_pos == w_pos - 4 ||
                    r_pos == q_pos || r_pos == q_pos + 4 || r_pos == q_pos - 4 ||
                    r_pos == e_pos || r_pos == e_pos + 4 || r_pos == e_pos - 4);

            setText(w_pos, "W");
            setText(q_pos, "Q");
            setText(e_pos, "E");
            setText(r_pos, "R");

            int[] tmp_x = new int[4];

            tmp_x[0] = getNumber(0, 4);

            do
            {
                tmp_x[1] = getNumber(0, 4);
            } while (tmp_x[1] == tmp_x[0]);

            do
            {
                tmp_x[2] = getNumber(0, 4);
            } while (tmp_x[2] == tmp_x[0] || tmp_x[2] == tmp_x[1]);

            do
            {
                tmp_x[3] = getNumber(0, 4);
            } while (tmp_x[3] == tmp_x[0] || tmp_x[3] == tmp_x[1] || tmp_x[3] == tmp_x[2]);

            Random rnd_y = new Random();
            Wbutton.Left = tmp_x[0] * Wbutton.Width;
            Wbutton.Top = 17 + rnd_y.Next(0, 2) * Wbutton.Height;
            Qbutton.Left = tmp_x[1] * Wbutton.Width;
            Qbutton.Top = 17 + rnd_y.Next(0, 2) * Wbutton.Height;
            Ebutton.Left = tmp_x[2] * Wbutton.Width;
            Ebutton.Top = 17 + rnd_y.Next(0, 2) * Wbutton.Height;
            Rbutton.Left = tmp_x[3] * Wbutton.Width;
            Rbutton.Top = 17 + rnd_y.Next(0, 2) * Wbutton.Height;
        }


        bool isW = false, isQ = false, isE = false, isR = false, setting = false;
        bool isWin = false;

        private void Wbutton_Click(object sender, EventArgs e)
        {
            isW = true;
            isQ = false;
            isE = false;
            isR = false;
            hScrollBar1.Value = Wbutton.Left / 92;
            vScrollBar1.Value = (Wbutton.Top - 17) / 88;
        }

        private void Qbutton_Click(object sender, EventArgs e)
        {
            isW = false;
            isQ = true;
            isE = false;
            isR = false;
            hScrollBar1.Value = Qbutton.Left / 92;
            vScrollBar1.Value = (Qbutton.Top - 17) / 88;
        }

        private void Ebutton_Click(object sender, EventArgs e)
        {
            isW = false;
            isQ = false;
            isE = true;
            isR = false;
            hScrollBar1.Value = Ebutton.Left / 92;
            vScrollBar1.Value = (Ebutton.Top - 17) / 88;
        }

        private void Rbutton_Click(object sender, EventArgs e)
        {
            isW = false;
            isQ = false;
            isE = false;
            isR = true;
            hScrollBar1.Value = Rbutton.Left / 92;
            vScrollBar1.Value = (Rbutton.Top - 17) / 88;
        }


        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            if (isW)
                Wbutton.Left = hScrollBar1.Value * Wbutton.Width;
            else if (isQ)
                Qbutton.Left = hScrollBar1.Value * Qbutton.Width;
            else if (isE)
                Ebutton.Left = hScrollBar1.Value * Ebutton.Width;
            else if (isR)
                Rbutton.Left = hScrollBar1.Value * Rbutton.Width;

            if (!isWin)
            {
                isCorrect();
                if (isWin)
                {
                    timer1.Stop();
                    MessageBox.Show("Correct! " + label0.Text);
                }               
            }
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            if (isW)
                Wbutton.Top = 17 + vScrollBar1.Value * Wbutton.Height;
            else if (isQ)
                Qbutton.Top = 17 + vScrollBar1.Value * Qbutton.Height;
            else if (isE)
                Ebutton.Top = 17 + vScrollBar1.Value * Ebutton.Height;
            else if (isR)
                Rbutton.Top = 17 + vScrollBar1.Value * Rbutton.Height;

            if (!isWin)
            {
                isCorrect();
                if (isWin)
                {
                    timer1.Stop();
                    MessageBox.Show("Correct! " + label0.Text);
                }
            }
        }

        int sec = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            sec++;      
            label0.Text = $"Used {sec} second(s)";
        }

        private void isCorrect()
        {

            int correct_cnt = 0;

                if (label1.Text == "W")
                {
                    if ((0 == Wbutton.Left / 92) &&
                        (0 == (Wbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label2.Text == "W")
                {
                    if ((1 == Wbutton.Left / 92) &&
                        (0 == (Wbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }
                if (label3.Text == "W")
                {
                    if ((2 == Wbutton.Left / 92) &&
                        (0 == (Wbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }
                    
                if (label4.Text == "W")
                {
                    if ((3 == Wbutton.Left / 92) &&
                        (0 == (Wbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }
                        
                if (label5.Text == "W")
                {
                    if ((0 == Wbutton.Left / 92) &&
                        (1 == (Wbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }
                            
                                
                if (label6.Text == "W")
                {
                    if ((1 == Wbutton.Left / 92) &&
                        (1 == (Wbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }
                                
                                    
                if (label7.Text == "W")
                {
                    if ((2 == Wbutton.Left / 92) &&
                        (1 == (Wbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }                        
                }
                                    
                if (label8.Text == "W")
                {
                    if ((3 == Wbutton.Left / 92) &&
                        (1 == (Wbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }                        
                }                                      

                if (label1.Text == "Q")
                {
                    if ((0 == Qbutton.Left / 92) &&
                        (0 == (Qbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label2.Text == "Q")
                {
                    if ((1 == Qbutton.Left / 92) &&
                        (0 == (Qbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }
                if (label3.Text == "Q")
                {
                    if ((2 == Qbutton.Left / 92) &&
                        (0 == (Qbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label4.Text == "Q")
                {
                    if ((3 == Qbutton.Left / 92) &&
                        (0 == (Qbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label5.Text == "Q")
                {
                    if ((0 == Qbutton.Left / 92) &&
                        (1 == (Qbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }


                if (label6.Text == "Q")
                {
                    if ((1 == Qbutton.Left / 92) &&
                        (1 == (Qbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }


                if (label7.Text == "Q")
                {
                    if ((2 == Qbutton.Left / 92) &&
                        (1 == (Qbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label8.Text == "Q")
                {
                    if ((3 == Qbutton.Left / 92) &&
                        (1 == (Qbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label1.Text == "E")
                {
                    if ((0 == Ebutton.Left / 92) &&
                        (0 == (Ebutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label2.Text == "E")
                {
                    if ((1 == Ebutton.Left / 92) &&
                        (0 == (Ebutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }
                if (label3.Text == "E")
                {
                    if ((2 == Ebutton.Left / 92) &&
                        (0 == (Ebutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label4.Text == "E")
                {
                    if ((3 == Ebutton.Left / 92) &&
                        (0 == (Ebutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label5.Text == "E")
                {
                    if ((0 == Ebutton.Left / 92) &&
                        (1 == (Ebutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }


                if (label6.Text == "E")
                {
                    if ((1 == Ebutton.Left / 92) &&
                        (1 == (Ebutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }


                if (label7.Text == "E")
                {
                    if ((2 == Ebutton.Left / 92) &&
                        (1 == (Ebutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label8.Text == "E")
                {
                    if ((3 == Ebutton.Left / 92) &&
                        (1 == (Ebutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label1.Text == "R")
                {
                    if ((0 == Rbutton.Left / 92) &&
                        (0 == (Rbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label2.Text == "R")
                {
                    if ((1 == Rbutton.Left / 92) &&
                        (0 == (Rbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }
                if (label3.Text == "R")
                {
                    if ((2 == Rbutton.Left / 92) &&
                        (0 == (Rbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label4.Text == "R")
                {
                    if ((3 == Rbutton.Left / 92) &&
                        (0 == (Rbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label5.Text == "R")
                {
                    if ((0 == Rbutton.Left / 92) &&
                        (1 == (Rbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }


                if (label6.Text == "R")
                {
                    if ((1 == Rbutton.Left / 92) &&
                        (1 == (Rbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }


                if (label7.Text == "R")
                {
                    if ((2 == Rbutton.Left / 92) &&
                        (1 == (Rbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

                if (label8.Text == "R")
                {
                    if ((3 == Rbutton.Left / 92) &&
                        (1 == (Rbutton.Top - 17) / 88))
                    {
                        correct_cnt++;
                    }
                }

            if (correct_cnt == 4) 
            {
                isWin = true;
            }

        }
    
    }
}
