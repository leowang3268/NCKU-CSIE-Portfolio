﻿namespace practice7_2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.auto_solve_button = new System.Windows.Forms.Button();
            this.restart_button = new System.Windows.Forms.Button();
            this.up_button = new System.Windows.Forms.Button();
            this.left_button = new System.Windows.Forms.Button();
            this.down_button = new System.Windows.Forms.Button();
            this.right_button = new System.Windows.Forms.Button();
            this.fileDialog = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(571, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Used ";
            // 
            // auto_solve_button
            // 
            this.auto_solve_button.Location = new System.Drawing.Point(559, 82);
            this.auto_solve_button.Name = "auto_solve_button";
            this.auto_solve_button.Size = new System.Drawing.Size(210, 44);
            this.auto_solve_button.TabIndex = 2;
            this.auto_solve_button.Text = "Import Auto Solve Step";
            this.auto_solve_button.UseVisualStyleBackColor = true;
            this.auto_solve_button.Click += new System.EventHandler(this.auto_solve_button_Click);
            // 
            // restart_button
            // 
            this.restart_button.Location = new System.Drawing.Point(559, 146);
            this.restart_button.Name = "restart_button";
            this.restart_button.Size = new System.Drawing.Size(210, 44);
            this.restart_button.TabIndex = 3;
            this.restart_button.Text = "Restart";
            this.restart_button.UseVisualStyleBackColor = true;
            this.restart_button.Click += new System.EventHandler(this.restart_button_Click);
            // 
            // up_button
            // 
            this.up_button.Location = new System.Drawing.Point(632, 277);
            this.up_button.Name = "up_button";
            this.up_button.Size = new System.Drawing.Size(64, 64);
            this.up_button.TabIndex = 4;
            this.up_button.Text = "Up";
            this.up_button.UseVisualStyleBackColor = true;
            this.up_button.Click += new System.EventHandler(this.up_button_Click);
            // 
            // left_button
            // 
            this.left_button.Location = new System.Drawing.Point(559, 352);
            this.left_button.Name = "left_button";
            this.left_button.Size = new System.Drawing.Size(64, 64);
            this.left_button.TabIndex = 5;
            this.left_button.Text = "Left";
            this.left_button.UseVisualStyleBackColor = true;
            this.left_button.Click += new System.EventHandler(this.left_button_Click);
            // 
            // down_button
            // 
            this.down_button.Location = new System.Drawing.Point(632, 352);
            this.down_button.Name = "down_button";
            this.down_button.Size = new System.Drawing.Size(64, 64);
            this.down_button.TabIndex = 6;
            this.down_button.Text = "Down";
            this.down_button.UseVisualStyleBackColor = true;
            this.down_button.Click += new System.EventHandler(this.down_button_Click);
            // 
            // right_button
            // 
            this.right_button.Location = new System.Drawing.Point(705, 352);
            this.right_button.Name = "right_button";
            this.right_button.Size = new System.Drawing.Size(64, 64);
            this.right_button.TabIndex = 7;
            this.right_button.Text = "Right";
            this.right_button.UseVisualStyleBackColor = true;
            this.right_button.Click += new System.EventHandler(this.right_button_Click);
            // 
            // fileDialog
            // 
            this.fileDialog.FileName = "openFileDialog1";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.right_button);
            this.Controls.Add(this.down_button);
            this.Controls.Add(this.left_button);
            this.Controls.Add(this.up_button);
            this.Controls.Add(this.restart_button);
            this.Controls.Add(this.auto_solve_button);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button auto_solve_button;
        private System.Windows.Forms.Button restart_button;
        private System.Windows.Forms.Button up_button;
        private System.Windows.Forms.Button left_button;
        private System.Windows.Forms.Button down_button;
        private System.Windows.Forms.Button right_button;
        private System.Windows.Forms.OpenFileDialog fileDialog;
        private System.Windows.Forms.Timer timer1;
    }
}

