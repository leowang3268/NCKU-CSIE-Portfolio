﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace practice7_2
{


    public partial class Form1 : Form
    {

        public class Cars : Button
        {
            public int length;
            public int setLength(string CarType)
            {
                switch (CarType)
                {
                    case "R":
                        return 2;
                    case "B":
                        return 4;
                    case "V":
                        return 3;
                }
                return 0;
            }
            public Color setColor(string CarType)
            {
                switch (CarType)
                {
                    case "R":
                        return Color.Red;
                        break;
                    case "B":
                        return Color.Yellow;
                        break;
                    case "V":
                        return Color.LightBlue;
                        break;
                }
                return Color.White;
            }
        }

        public class RedCar : Cars
        {

        }

        public class Bus : Cars
        {

        }

        public class Van : Cars
        {

        }

        public Form1()
        {
            InitializeComponent();

        }

        Button[] button = new Button[20];
        RedCar redcar = new RedCar();
        Bus bus = new Bus();
        Van van = new Van();
        int index = 0, unit_length = 56, origin_x = 40, origin_y = 15;
        bool[] canMove = new bool[20];
        string data;
        string carType;
        int isHorizontal;
        int[] pos_x = new int[20];
        int[] pos_y = new int[20];
        private void Form1_Load(object sender, EventArgs e)
        {
            
            StreamReader sr = new StreamReader (@"test.map.txt");

            do
            {
                button[index] = new Button();
                button[index].Click += new EventHandler(Button_Click);              
                button[index].Text = "";
                data = sr.ReadLine();            // 讀取一行文字資料
                if (data == null) break;         // 若資料讀取完畢，跳離迴圈
                string[] dataArray = data.Split(' ');
                button[index].Text = dataArray[0];
                carType = dataArray[1];
                isHorizontal = Convert.ToInt32(dataArray[2]);
                pos_x[index] = Convert.ToInt32(dataArray[3]);
                pos_y[index] = Convert.ToInt32(dataArray[4]);
                switch(carType)    // 把每個button依序叫去改 (根據car_type, horizontal等數值)
                {
                    case "R":                       
                        button[index].BackColor = redcar.setColor(carType);
                        int redcar_length = redcar.setLength(carType);
                        if (isHorizontal == 1)
                        {
                            button[index].Width = redcar_length * unit_length;
                            button[index].Height = unit_length;
                        }
                        else if (isHorizontal == 0)
                        {
                            button[index].Width = unit_length;
                            button[index].Height = redcar_length * unit_length;
                        }
                        button[index].Left = origin_x + pos_x[index] * unit_length;
                        button[index].Top = origin_y + pos_y[index] * unit_length;
                        this.Controls.Add(button[index]);
                        

                        break;

                    case "B":                        
                        button[index].BackColor = bus.setColor(carType);
                        int bus_length = bus.setLength(carType);
                        if (isHorizontal == 1)
                        {
                            button[index].Width = bus_length * unit_length;
                            button[index].Height = unit_length;
                        }
                        else if (isHorizontal == 0)
                        {
                            button[index].Width = unit_length;
                            button[index].Height = 4 * unit_length;
                        }
                        button[index].Left = origin_x + pos_x[index] * unit_length;
                        button[index].Top = origin_y + pos_y[index] * unit_length;
                        this.Controls.Add(button[index]);
                        

                        break;

                    case "V":
                        button[index].BackColor = van.setColor(carType);
                        int van_length = van.setLength(carType);
                        button[index].BackColor = Color.LightBlue;
                        if (isHorizontal == 1)
                        {
                            button[index].Width = 3 * unit_length;
                            button[index].Height = unit_length;
                        }
                        else if (isHorizontal == 0)
                        {
                            button[index].Width = unit_length;
                            button[index].Height = 3 * unit_length;
                        }
                        button[index].Left = origin_x + pos_x[index] * unit_length;
                        button[index].Top = origin_y + pos_y[index] * unit_length;
                        this.Controls.Add(button[index]);
                        

                        break;
                }
                index++;
            } while (true);
            sr.Close();
        }
        //車子重疊待處理(√)

        private void Button_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < index; i++)
            {
                if ((sender as Button).Text == button[i].Text) 
                    canMove[i] = true;
                else
                    canMove[i] = false;
            }       
        }

        private void up_button_Click(object sender, EventArgs e)
        {
            
            for (int i = 0; i < index; i++)
            {
                if (canMove[i] == true)
                {
                    for (int j = 0; j < index; j++)
                    {
                        if (j == i) continue;
                        else
                        {
                            if (button[i].Top == button[j].Bottom && (button[i].Left >= button[j].Left && button[i].Right <= button[j].Right))
                                return;
                        }
                    }

                    if (button[i].Width > button[i].Height || button[i].Top == origin_y)
                    {
                        return;
                    }

                    else
                    {
                        button[i].Top -= unit_length;
                    }
                }
            }
            if (isWin())
            {
                timer1.Stop();
                MessageBox.Show("You Won! " + label1.Text);
            }
        }

        private void down_button_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < index; i++)
            {
                if (canMove[i] == true)
                {
                    for (int j = 0; j < index; j++)
                    {
                        if (j == i) continue;
                        else
                        {
                            if (button[i].Bottom == button[j].Top && (button[i].Left >= button[j].Left && button[i].Right <= button[j].Right))
                                return;
                        }
                    }

                    if (button[i].Width > button[i].Height || button[i].Bottom == origin_y + 6 * unit_length)
                    {
                        return;
                    }

                    else
                    {
                        button[i].Top += unit_length;
                    }
                }
            }
            if (isWin())
            {
                timer1.Stop();
                MessageBox.Show($"You Won! Used {sec} second(s).");
            }
        }

        private void left_button_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < index; i++)
            {
                if (canMove[i] == true)
                {
                    for (int j = 0; j < index; j++)
                    {
                        if (j == i) continue;
                        else
                        {
                            if (button[i].Left == button[j].Right && (button[i].Top >= button[j].Top && button[i].Bottom <= button[j].Bottom))
                                return;
                        }
                    }

                    if (button[i].Width < button[i].Height || button[i].Left == origin_x)
                    {
                        return;
                    }

                    else
                    {
                        button[i].Left -= unit_length;
                    }
                }
            }
            if (isWin())
            {
                timer1.Stop();
                MessageBox.Show("You Won! " + label1.Text);
            }
        }

        private void right_button_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < index; i++)
            {
                if (canMove[i] == true)
                {
                    
                    for (int j = 0; j < index; j++)
                    {
                        if (j == i) continue;
                        else
                        {
                            if (button[i].Right == button[j].Left && (button[i].Top >= button[j].Top && button[i].Bottom <= button[j].Bottom))
                            {
                                return;
                            }
                                
                        }
                    }

                    if (button[i].Width < button[i].Height || button[i].Right == origin_x + 6 * unit_length)
                    {
                        return;
                    }

                    else
                    {
                        button[i].Left += unit_length;
                    }
                }
            }
            if(isWin())
            {
                timer1.Stop();
                MessageBox.Show("You Won! " + label1.Text);
            }
                
        }

        private bool isWin()
        {
            for (int i = 0; i < index; i++)
            {
                if(button[i].BackColor == Color.Red)
                {
                    for (int j = 0; j < 6; j++) // x-axis traversal
                    {
                        for (int k = 0; k < index; k++) // check if any button block the path
                        {
                            if (k == i) continue;
                            if (!((button[k].Width > button[k].Height && button[i].Right + j * unit_length == button[k].Right
                                && button[i].Top == button[k].Top) ||
                                (button[k].Width < button[k].Height && button[i].Right + j * unit_length == button[k].Right
                                && button[i].Top >= button[k].Top && button[i].Top <= button[k].Bottom ))) 
                                continue;
                            else
                                return false;
                        }                        
                    }
                }               
            }
            return true;
        }


        int cnt = 0;
        private void auto_solve_button_Click(object sender, EventArgs e)
        {
            //timer1.Stop();
            Stream myStream = null;
            fileDialog.Title = "Select File";
            fileDialog.InitialDirectory = @"test.path.txt";
            fileDialog.Filter = "Txt(*.txt)|*.txt";
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                for (int i = 0; i < index; i++)
                {
                    button[i].Left = origin_x + pos_x[i] * unit_length;
                    button[i].Top = origin_y + pos_y[i] * unit_length;
                }

                StreamReader Openfile = new StreamReader(fileDialog.FileName);
                Thread.Sleep(1000);
                string data;
                int which;
                string direction;
                do
                {
                    data = Openfile.ReadLine();
                    if (data == null) break;
                    string[] dataArray = data.Split(' ');
                    which = Convert.ToInt32(dataArray[0]) - 1;
                    direction = dataArray[1];
                    for (int i = 0; i < index; i++)
                    {
                        if (i == which)
                            canMove[i] = true;
                        else
                            canMove[i] = false;
                    }
                    switch(direction)
                    {
                        case "U":
                            up_button_Click(sender, e);
                            break;

                        case "D":
                            down_button_Click(sender, e);
                            break;

                        case "L":
                            left_button_Click(sender, e);
                            break;

                        case "R":
                            right_button_Click(sender, e);
                            break;
                    }
                    Thread.Sleep(1000);
                    cnt++;
                } while (true);     
            }            
            fileDialog.Dispose();
        }

        

        private void restart_button_Click(object sender, EventArgs e)
        {
            //for (int i = 0; i < index; i++)
            //{
            //    this.Controls.Remove(button[i]);
            //}
            //Form1_Load(sender, e);
            /*
            Form1 form = new Form1();
            this.Hide();
            form.Show();
            */
            for (int i = 0; i < index; i++)
            {
                button[i].Left = origin_x + pos_x[i] * unit_length;
                button[i].Top = origin_y + pos_y[i] * unit_length;
            }
            sec = 0;
        }

        int sec = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            sec++;
            label1.Text = $"Used {sec} second(s)";
        }
    }
}
