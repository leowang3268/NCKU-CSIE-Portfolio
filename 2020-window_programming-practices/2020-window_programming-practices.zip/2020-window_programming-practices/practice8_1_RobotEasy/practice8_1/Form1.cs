﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace practice8_1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void 開啟聊天機器人ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("11");
        }

        private void 結束程式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("12");
        }

        private void 字體ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.Font = fontDialog1.Font;
            }
        }

        private void 顏色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.ForeColor = colorDialog1.Color;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
            {
                button1_Click(sender, e);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            textBox1.AppendText("Me: " + textBox2.Text.Replace("\r\n", string.Empty) + "\r\n"
                + "Machine: " + "你好" + "\r\n");

            /*
            if (!File.Exists("./../../Record.txt"))
            {
                //沒有則創建這個文件
                FileStream fs1 = new FileStream("./../../Record.txt", FileMode.Create, FileAccess.Write);//創建寫入文件
            }
            */
            // Append text to an existing file named "Record.txt".
            using (StreamWriter outputFile = File.AppendText("./../../Record.txt"))
            {
                string text = "Me: " + textBox2.Text.Replace("\r\n", string.Empty) + "\r\n"
                   + "Machine: " + "你好";
                outputFile.WriteLine(text);
                outputFile.Flush();
                outputFile.Close();
            }


            textBox2.Text = "";
        }

        int sec = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            sec++;
            label1.Text = $"User: {sec} second(s)";
        }

        Bitmap pict;
        private void button2_Click(object sender, EventArgs e)
        {

            OpenFileDialog openPic = new OpenFileDialog();
            openPic.Title = "Select Picture";
            openPic.Filter = "JPG(*.JPG;*.JPEG);gif文件(*.GIF);PNG(*.png)|*.jpg;*.jpeg;*.gif;*.png";
            openPic.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (openPic.ShowDialog() == DialogResult.OK)
            {
                pict = new Bitmap(openPic.FileName);
                this.pictureBox1.Image = pict;
            }
        }
    }
}
