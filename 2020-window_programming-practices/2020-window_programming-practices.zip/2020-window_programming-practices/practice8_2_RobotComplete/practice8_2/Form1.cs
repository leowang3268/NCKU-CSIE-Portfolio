﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace practice8_1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

        }

        private void 開啟聊天機器人ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
        
        }

        private void 結束程式ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 字體ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.Font = fontDialog1.Font;
            }
        }

        private void 顏色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.ForeColor = colorDialog1.Color;
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
            {
                button1_Click(sender, e);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(Form2.mode1)
            {
                Mode1_Robot r1 = new Mode1_Robot();
                r1.mode = "Model1_";
                string str2 = textBox2.Text.Replace("\r\n", string.Empty);
                textBox1.AppendText("Me: " + str2 + "\r\n");
                textBox1.AppendText(r1.talk(r1.mode, str2));
                using (StreamWriter outputFile = File.AppendText("./../../Record.txt"))
                {
                    outputFile.WriteLine("Me: " + str2 + "\r\n"
                    + r1.talk(r1.mode, str2).Replace("\r\n", string.Empty));
                    outputFile.Flush();
                    outputFile.Close();
                }
            }
            else if (Form2.mode2)
            {
                Mode2_Robot r2 = new Mode2_Robot();
                r2.mode = "Model2_";
                string str2 = textBox2.Text.Replace("\r\n", string.Empty);
                textBox1.AppendText("Me: " + str2 + "\r\n");
                textBox1.AppendText(r2.talk(r2.mode, str2));
                using (StreamWriter outputFile = File.AppendText("./../../Record.txt"))
                {
                    outputFile.WriteLine("Me: " + str2 + "\r\n"
                    + r2.talk(r2.mode, str2).Replace("\r\n", string.Empty));
                    outputFile.Flush();
                    outputFile.Close();
                }
            }
            else
            {
                MessageBox.Show("請先開啟聊天機器人");
            }           
            textBox2.Text = "";



            /*
            if (!File.Exists("./../../Record.txt"))
            {
                //沒有則創建這個文件
                FileStream fs1 = new FileStream("./../../Record.txt", FileMode.Create, FileAccess.Write);//創建寫入文件
            }
            */

            // Append text to an existing file named "Record.txt".
        }

        int sec = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            sec++;
            label1.Text = $"User: {sec} second(s)";
        }

        Bitmap pict;
        private void button2_Click(object sender, EventArgs e)
        {

            OpenFileDialog openPic = new OpenFileDialog();
            openPic.Title = "Select Picture";
            openPic.Filter = "JPG(*.JPG;*.JPEG);gif文件(*.GIF);PNG(*.png)|*.jpg;*.jpeg;*.gif;*.png";
            openPic.InitialDirectory = Path.GetDirectoryName(Application.ExecutablePath);
            if (openPic.ShowDialog() == DialogResult.OK)
            {
                pict = new Bitmap(openPic.FileName);
                this.pictureBox1.Image = pict;
            }
        }
    }
}
