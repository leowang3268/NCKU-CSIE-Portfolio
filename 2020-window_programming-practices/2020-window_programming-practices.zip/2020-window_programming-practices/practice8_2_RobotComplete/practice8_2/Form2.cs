﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace practice8_1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

        }

        public static bool mode1 = false, mode2 = false;
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer2.Enabled = true;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            if (!File.Exists("./../../Record.txt"))
            {
                MessageBox.Show("尚未有聊天紀錄");
            }
            else
            {
                StreamReader sr = new StreamReader("./../../Record.txt");
                do
                {
                    string data = sr.ReadLine();
                    if (data == null) break;
                    textBox2.AppendText(data + "\r\n");
                } while (true);
                sr.Close();
            }               
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.PerformStep();
            if (progressBar1.Value == progressBar1.Maximum)
            {
                mode1 = true;
                mode2 = false;
                timer1.Enabled = false;		// 計時器停止
                progressBar1.Value = 0;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {

            progressBar2.PerformStep();
            if (progressBar2.Value == progressBar1.Maximum)
            {
                mode2 = true;
                mode1 = false;
                timer2.Enabled = false;		// 計時器停止
                progressBar2.Value = 0;
            }
        }
    }
}
