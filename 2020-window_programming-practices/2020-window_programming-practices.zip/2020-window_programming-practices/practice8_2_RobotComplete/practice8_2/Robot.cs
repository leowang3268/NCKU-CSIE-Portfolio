﻿////using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practice8_1
{
    class Robot
    {
        public string mode { get; set; }
        public string talk(string mode, string str2)
        {
            string say = "Machine: " + mode + str2 + "\r\n";
            return say;
        }
    }
}
